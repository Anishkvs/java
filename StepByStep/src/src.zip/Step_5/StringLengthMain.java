package Step_5;

public class StringLengthMain {

	public static void main(String[] args) {
		
		StringLength lg = new StringLength();
		lg.getData();
		lg.trimData();
		lg.upperLower();
		lg.SpecificText();
	}
}
