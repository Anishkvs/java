package Step_5;

public class StringHandlingPart2Main {
	
	public static void main(String[] args) {
		/*
		 * 1
		 * 
		 * 3. 
		 * 4. 
		 * 5. 
		 */
		StringHandlingPart2 obj = new StringHandlingPart2();
		obj.ReplaceData();
		obj.findText();
		obj.Concatenate();
		obj.substring();
		obj.StringExist();
		obj.SplitString();
		
	}

}
