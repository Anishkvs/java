package Step_5;

public class StringHandling {

	/* String is not DataType in Java
	 * String is Class in Java
	 * String perform different operation & calling methods	
	 */
	int i;
	char b;
	float f;
	boolean h;
	String S;
	
	
}
