package Step_5;

import java.security.PublicKey;

public class StringHandlingPart3Main {

	//Compare 2 String with case sensitive
	//Compare 2 String with case InSensitive
	
	public static void main(String[] args) {
		
		StringHandlingPart3 obj = new StringHandlingPart3();
		obj.caseSensitive();
		obj.caseInSensitive();
		
	
	
	}
}
