package Step_5;

public class praticeMain {

	public static void main(String[] args) {
		
		pratice obj = new pratice();
		obj.getDat();
		obj.trim();
		obj.textt();
		obj.specific();
		obj.SplitString();
	}
}
