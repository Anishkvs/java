package MathameticCalculation;

public class SquareSum {
	/*
	 * Perform following calculation
	 * 		(Square 2) + (Square 5)
	 *       4   + 25 = 29
	 */
	
	public int Square(int a) {
		
		int c = a*a;
		return c;
	}
	
	public void sum(int a, int b) {
		
		int c = a+b;
		System.out.println(c);

	}
}
