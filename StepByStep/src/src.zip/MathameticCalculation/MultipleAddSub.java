package MathameticCalculation;

public class MultipleAddSub {
	/*
	 * Perform following calculation
	 * 		(2+8)*(2+5+7)
	 */
	
	public int sum(int a, int b) {
		int c = a+b;
		return c;
		
	}
	
	public int sumTwo(int a, int b, int c) {
		
		int d= a+b+c;
		return c;
		
	}
	
	public void multi(int a, int b) {
		
		int c = a*b;
		System.out.println(c);
	}
}
