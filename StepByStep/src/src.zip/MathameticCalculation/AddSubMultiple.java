package MathameticCalculation;

public class AddSubMultiple {

	/*
	 * Perform following calculation
	 * 		(2+3)*(5-2)
	 */
	
	public int add(int a, int b) {
		
		int c = a+b;
		return c;

	}
	
	public int sub(int a, int b) {
		
		int c = a-b;
		return c;
	}
	
	public void mult(int a, int b) {
		int c = a*b;
		System.out.println(c);

	}
}
