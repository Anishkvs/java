package MathameticCalculation;

public class AddSubMultipleMain {
 
	public static void main(String[] args) {
		
	
	AddSubMultiple obj = new AddSubMultiple();
	int x = obj.add(2, 5);
	int y = obj.sub(8, 5);
	obj.mult(x, y);
	
	}
}
