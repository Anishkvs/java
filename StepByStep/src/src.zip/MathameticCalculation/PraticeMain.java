package MathameticCalculation;

public class PraticeMain {
	
	public static void main(String[] args) {
		
	
	Pratice obj = new Pratice();
	int x= obj.Square(2);
	int y =obj.Square(5);
	obj.sum(x,y);
	
	}
}
