package MathameticCalculation;

public class SquareSumMain {

	public static void main(String[] args) {

		SquareSum obj = new SquareSum();
		int x = obj.Square(2);
		int y = obj.Square(5);
		obj.sum(x, y);
		

	}

}
