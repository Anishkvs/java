package MultiLevelInHeritance;

public class A {

	public void AClassMethod() 
	{
		System.out.println("Parent class Level: 1");
	}
}
