package MultiLevelInHeritance;

public class C extends B{

	public void CClassMethod() 
	{
		System.out.println("Child class Level: 3 C");
	}


}
