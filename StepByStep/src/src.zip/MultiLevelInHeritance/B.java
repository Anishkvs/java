package MultiLevelInHeritance;

public class B extends A{

	public void BClassMethod() 
	{
		System.out.println("Child class Level: 2 B");
	}
}
