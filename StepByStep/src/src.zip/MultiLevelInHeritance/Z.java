package MultiLevelInHeritance;

public class Z {

	public static void main(String[] args) {
		
		D obj = new D();
		obj.DClassMethod();
		obj.CClassMethod();
		obj.BClassMethod();
		obj.AClassMethod();

	}

}
