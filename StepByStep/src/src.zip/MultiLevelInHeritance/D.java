package MultiLevelInHeritance;

public class D extends C{
	
	public void DClassMethod() 
	{
		System.out.println("Child class Level: 4 D");
	}
}
