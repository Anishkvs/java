package Constructor;

public class ExampleConstratorUses1 {
	
	public ExampleConstratorUses1() {
		System.out.println("Start browser + URL");
	}
	
	
	public void tc001() {
		System.out.println("Login - logout");
	}
	
	public void tc002() {
		System.out.println("Registration");

	}
	public void tc003() {
		System.out.println("Send mail");

	}
}
