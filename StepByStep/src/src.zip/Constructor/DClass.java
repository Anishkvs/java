package Constructor;

import method.*;


public class DClass {

	public static void main(String[] args) {
		
		
		CClass obj = new CClass(1,2);
		CClass obj1 = new CClass(10,25);
		
		/*
		 * Constructors
		 * 
        Constructors are similar to the method
		Constructor name is always same as Class name
		Constructor can take arguments but never returns value (ex: Void/Int/String not added)
		Constructors are automatically called when we create object of class
		 */
	}
	
}
