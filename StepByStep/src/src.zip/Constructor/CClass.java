package Constructor;

public class CClass {
	
		
	public  CClass(int a, int b) {
		int c = a+b;
		System.out.println(c);
	}
	
}
