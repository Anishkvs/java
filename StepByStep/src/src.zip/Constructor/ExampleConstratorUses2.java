package Constructor;

import method.*;

public class ExampleConstratorUses2 {

	public static void main(String[] args) {
		
		ExampleConstratorUses1 obj = new ExampleConstratorUses1();
		obj.tc002();
		
		
	}
	
}
