package Constructor;

import method.*;


public class BClass {

	public static void main(String[] args) {
		
		AClass obj = new AClass();
		
		/*
		 * Constructors
		 * 
        Constructors are similar to the method
		Constructor name is always same as Class name
		Constructor can take arguments but never returns value (ex: Void/Int/String not added)
		Constructors are automatically called when we create object of class
		 */
	}
	
}
