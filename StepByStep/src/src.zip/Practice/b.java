package Practice;

public class b {

	public static void main(String[] args) {
		a obj = new a();
		obj.star();
		
		
	}
}
