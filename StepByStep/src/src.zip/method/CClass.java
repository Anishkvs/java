package method;

public class CClass {

	public void beta() {
		System.out.println("Beta...");

	}
}
