package script;

public class numberSwipe {


	public static void main(String[] args) {
		
		int i = 100;
		int j = 200;
	//////////////////////////
		
		int k = i;    //k=100
			i = j;    //i=200
			j = k;     //j=100
			
			System.out.println(i );
			System.out.println( j);
	}

	
	
}
