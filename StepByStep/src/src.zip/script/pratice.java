package script;

public class pratice {
	
	
}
