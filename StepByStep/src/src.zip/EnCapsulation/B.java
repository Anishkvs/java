package EnCapsulation;

public class B {
	
	public static void main(String[] args) {
		
	A obj = new A();
	obj.setId(100);
	System.out.println(obj.getId());
	
	
//
//    
	
	}
}
