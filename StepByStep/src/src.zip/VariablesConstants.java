
public class VariablesConstants {
// step one:::::
	
	int marks = 80;
	int percentage;
	
	float calc = 11.3f;
	
	boolean b = true;
	
	char c = 'a';

// step two::::://Variables
	
	// Variables are used to hold data, variable value can be changed
	int markV = 80;
	int percentageV;
	
// step three::::://Constants
	
	// Constants are used to hold data, Constants value cann't be changed
	//Final keyword is used	
		final int marksC = 80;
		final int percentageC;
			
		
}
