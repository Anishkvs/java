package Step_3;

public class ConditionOrAndMain {

	
	public static void main(String[] args) {
		
		ConditionOrAnd obj = new ConditionOrAnd();
		obj.getData(25);
	}
}
