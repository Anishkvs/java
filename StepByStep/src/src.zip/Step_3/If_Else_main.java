package Step_3;

public class If_Else_main {

	public static void main(String[] args) {
		
		if_Else obj = new if_Else();
		obj.check(11);
	}
}
