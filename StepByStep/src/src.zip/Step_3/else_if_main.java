package Step_3;

public class else_if_main {

	public static void main(String[] args) {
		
		else_if obj = new else_if();
		obj.getData(0);
	}
}
