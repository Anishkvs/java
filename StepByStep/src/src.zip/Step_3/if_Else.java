package Step_3;

public class if_Else {

	public void check(int a) {
		
		if(a%2==0)
		{
			System.out.println("This is even number");
		}else
		{
			System.out.println("This is odd number");
		}

	}
		
		
	
}
