package Step_3;

public class NestedConditionMain {
	
	public static void main(String[] args) {
		NestedCondition obj = new NestedCondition();
		obj.getData(7);
	}
	
	
	
}
