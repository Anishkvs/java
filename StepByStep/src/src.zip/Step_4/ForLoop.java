package Step_4;

public class ForLoop {

	public void getData() {
		
		//For loop
	
		for(int i=1; i<=10; i++) {
		System.out.println("Hello.....");
		System.out.println(i);
		}
	}
	
	public void getDataReverse() {
		
		for(int i=10; i>=1; i--) {
			System.out.println(i);
		}
	}
	
}
