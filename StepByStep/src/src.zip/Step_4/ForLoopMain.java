package Step_4;

public class ForLoopMain {
	
	public static void main(String[] args) {
		ForLoop obj = new ForLoop();
		//obj.getData();
		obj.getDataReverse();
	}
	

}
