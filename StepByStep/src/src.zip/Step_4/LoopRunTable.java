package Step_4;

public class LoopRunTable {
	
	public void printTable(int a) {
		
		for(int i=1; i<=10; i++) {
		//	System.out.println(i*a);
			System.out.println("2 * " +i+ " = "+ i*a);
	
		}
	}



}
