package Step_4;

public class whileLoop {

	public void printTab() {
		
		int i=1;
		while(i<=15) {
			System.out.println(i);
			i++;
		}
		System.out.println("Task is done...");

	}
	
	public void doWhile() {
		
		int j=1;
		do {
			System.out.println(j);
			j++;
		}
		while( j<=10); 
		 

	}
	
	
}
