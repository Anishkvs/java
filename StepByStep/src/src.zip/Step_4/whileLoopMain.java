package Step_4;

public class whileLoopMain {

	
	/*
	 For Loop
	 * Rule 1: WhenEver you are confirm how many times we need to run loop
     * Rule 2: WhenEver value increase/Decrease constantly
	 * 
     While Loop
       Rule 1: Not Confirm, Then use while loop
	   Rule 2: Increment/decrement is not constant, use while loop
	 */
	public static void main(String[] args) {
		whileLoop obj = new whileLoop();
		obj.printTab();
		obj.doWhile();
	}
	
}
