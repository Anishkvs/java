package Step_4;

public class LoopInsideLoopMain {

	public static void main(String[] args) {
		
		LoopInsideLoop obj = new LoopInsideLoop();
		obj.getDat();
	}
}
