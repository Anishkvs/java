package Step_4;

public class LoopInsideLoop {

	public void getDat() {
		for(int i=1; i<=5; i++) {
			
			 for(int j=1; j<=4; j++) {
				 
				 System.out.println(j);
			 }
		}

	}
	
}
