package Step_4;

public class LoopRunTableMain {
	
	/*
	 * For Loop
	 * Print table using Arguments
	 * 2 * 1 = 2
	 * 2 * 2 = 4
	 * Rule 1: WhenEver you are confirm how many times we need to run loop
     * Rule 2: WhenEver value increase/Decrease constantly
	 */
	
	public static void main(String[] args) {
		LoopRunTable obj = new LoopRunTable();
		obj.printTable(2);
	}
	
	
}
